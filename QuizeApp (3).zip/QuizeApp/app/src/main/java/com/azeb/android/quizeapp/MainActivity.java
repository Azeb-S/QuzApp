package com.azeb.android.quizeapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    int score = 0;
    RadioButton qOneCorrect;
    CheckBox qTwoCorrectOne;
    CheckBox qTwoCorrectTwo;
    CheckBox qTwoWrong;
    RadioButton qThreeCorrect;
    RadioButton qFourCorrect;
    RadioButton qFiveCorrect;
    EditText qEditText;
    String america = "America";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    private int correctAnsweres(boolean qOneCheked, boolean qthreeChked, boolean qFourChked, boolean qFiveChked,
                                boolean qTwoCBOne, boolean qTwoCBTwo, boolean qTwoCbThree, String editTextAnswer) {

        if (qOneCheked) {
            score = score + 1;
        }
        if (qthreeChked) {
            score = score + 1;
        }
        if (qFourChked) {
            score = score + 1;
        }
        if (qFiveChked) {
            score = score + 1;
        }
        if (qTwoCbThree && qTwoCBOne && qTwoCBTwo) {
            score = score + 1;
        }

        if(editTextAnswer.equalsIgnoreCase(america)) {
            score++;
        }else {
            score = score + 0;
        }
        return score;

    }

    public void submitScore(View view) {
        EditText nameField = (EditText) findViewById(R.id.name_edit_text);
        Editable nameEditable = nameField.getText();
        String name = nameEditable.toString();

        qEditText = (EditText)findViewById(R.id.answer_edit_text);
        Editable editableAnswer = qEditText.getText();
        String answer = editableAnswer.toString();

        qOneCorrect = (RadioButton) findViewById(R.id.rb_q_one_correct);
        qThreeCorrect = (RadioButton) findViewById(R.id.rb_q_three_correct);
        qFourCorrect = (RadioButton) findViewById(R.id.rb_q_four_correct);
        qFiveCorrect = (RadioButton) findViewById(R.id.rb_q_five_correct);

        boolean qOneChecked = qOneCorrect.isChecked();
        boolean qThreeChecked = qThreeCorrect.isChecked();
        boolean qFoureChecked = qFourCorrect.isChecked();
        boolean qFiveCheked = qFiveCorrect.isChecked();

        qTwoCorrectOne = (CheckBox) findViewById(R.id.cb_q_two_correct_one);
        qTwoCorrectTwo = (CheckBox) findViewById(R.id.cb_q_two_correct_two);
        qTwoWrong = (CheckBox)findViewById(R.id.cb_q_two_wrong);

        boolean qTwoCheckOne = qTwoCorrectOne.isChecked();
        boolean qTwoCheckedTwo = qTwoCorrectTwo.isChecked();
        boolean qTwoCheckedThree = !qTwoWrong.isChecked();

        int finalScore = correctAnsweres(qOneChecked, qThreeChecked, qFoureChecked, qFiveCheked, qTwoCheckOne, qTwoCheckedTwo,qTwoCheckedThree,answer);
        scorSummary(name, finalScore);
    }

    private void scorSummary(String name, int score) {

        if (score < 3) {

            Toast.makeText(this, "Hi " + name + " You have scored: " + score + " out of 7 give it a try one more time ", Toast.LENGTH_SHORT).show();



        }if (score > 3 && score <= 7){

            Toast.makeText(this, "Hi " + name + " You have scored: " + score + " out of 7. ", Toast.LENGTH_SHORT).show();
        }else {
            reset();
        }
    }
    private void reset(){
        score = 0;
    }
}
